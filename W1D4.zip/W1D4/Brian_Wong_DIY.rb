  require "Byebug"
  class Stack
    def initialize #stack is LIFO so you want to check the first element that leaves the queue
      @container = [] #make an empty array to implement stack
    end

    def push(el)
      @container << el
    end

    def pop #last in first out so pop it from the array
      @container.pop
    end

    def peek
      @container[-1]
    end
  end

  class Queue
    def initialize
        @container = []
    end

    def enqueue(el)
        @container.push(el)
    end

    def dequeue #remove the first element because of FIFO
        @container.shift
    end

    def peek #want to check that the first element you want to check the first element that leaves the queue
        @container[0]
    end
  end

  class Map
    attr_reader :container
    def initialize
        @container = []
    end

    def set(key,value) #find key and replace value with new value
         if self.get(key) == false
            @container << [key,value]
        #  else     
        #     @container << [key,replace_value(value)]
         end
    end
   
    def find_key(key) #check if the key exists
        @container.each do |sub_arr|
            if sub_arr[0] == key
                return true
            end
        end
        false
    end

    # def replace_value(value) #find key question ta
        
    #     if self.find_key(value) == true
            
    #     end
    # end
  

    def get(key)
        @container.each do |entry|
           return entry[1] if entry[0] == key
        end
        puts "key value pair do not exist"
        return false #if the key is not in the array, it will show the whole array. you want to return false
    end

    def delete(key)
        @container.each_with_index do |entry,idx|
           @container.delete_at(idx) if entry[0] == key
        end
    end

    def show
        @container
    end

    
  end
  
  p m = Map.new
  p m.set(3,4)
  p m.set(5,8)
  p m.set(8,3)
 
  p m.get(10)
  p m.set(8,8)